from experta import *


class Greetings(KnowledgeEngine):
	def __init__(self, symptom_map, if_not_matched, get_details):
		self.symptom_map = symptom_map
		self.if_not_matched = if_not_matched
		self.get_details = get_details
		KnowledgeEngine.__init__(self)

	# code giving instructions on how to use the Expert System
	@DefFacts()
	def _initial_action(self):
		print("")
		print("This is a knowledge based bot to diagnose diseases")
		print("")
		print("Do you feel any of the following symptoms?")
		print("Reply high or low or no")
		print("")
		yield Fact(action="find_disease")

	@Rule(Fact(action="find_disease"), NOT(Fact(fatigue=W())), salience=1)
	def symptom_0(self):
		self.declare(Fact(fatigue=input("fatigue: ")))

	@Rule(Fact(action="find_disease"), NOT(Fact(low_body_temp=W())), salience=1)
	def symptom_1(self):
		self.declare(Fact(low_body_temp=input("low body temperature: ")))

	@Rule(Fact(action="find_disease"), NOT(Fact(restlessness=W())), salience=1)
	def symptom_2(self):
		self.declare(Fact(restlessness=input("restlessness: ")))

	@Rule(Fact(action="find_disease"), NOT(Fact(sore_throat=W())), salience=1)
	def symptom_3(self):
		self.declare(Fact(sore_throat=input("sore throat: ")))

	@Rule(
		Fact(sore_throat="no"),
		Fact(fatigue="high"),
		Fact(restlessness="no"),
		Fact(low_body_temp="no"),
	)
	def disease_0(self):
		self.declare(Fact(disease="Jaundice"))

	@Rule(
		Fact(sore_throat="no"),
		Fact(fatigue="no"),
		Fact(restlessness="low"),
		Fact(low_body_temp="no"),
	)
	def disease_1(self):
		self.declare(Fact(disease="Asthma"))

	@Rule(
		Fact(sore_throat="no"),
		Fact(fatigue="no"),
		Fact(restlessness="no"),
		Fact(low_body_temp="high"),
	)
	def disease_2(self):
		self.declare(Fact(disease="Hypothermia"))

	@Rule(
		Fact(sore_throat="high"),
		Fact(fatigue="high"),
		Fact(restlessness="no"),
		Fact(low_body_temp="no"),
	)
	def disease_3(self):
		self.declare(Fact(disease="Coronavirus"))

	# Disease Matched
	@Rule(Fact(action="find_disease"), Fact(disease=MATCH.disease), salience=-998)
	def disease(self, disease):
		print("")
		id_disease = disease
		disease_details = self.get_details(id_disease)
		print("")
		print("Your symptoms match %s\n" % id_disease)
		print("A short description of the disease is given below :\n")
		print(disease_details + "\n")

	# Disease Not Matched
	@Rule(
		Fact(sore_throat=MATCH.sore_throat),
		Fact(fatigue=MATCH.fatigue),
		Fact(low_body_temp=MATCH.low_body_temp),
		Fact(restlessness=MATCH.restlessness),
	)
	def not_matched(self):
		print("\nThe bot did not find any diseases that match your exact symptoms.")
